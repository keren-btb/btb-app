import { Lock, LockOpen } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

// ---------------------------------------------------------------------------
// FAQs as little locked puzzles: tap a question, the padlock springs open, a
// "CRACKED" stamp lands and the answer decodes itself letter by letter.
// Only one answer is open at a time: opening another closes the first.
// To add or change a question, edit the `faqs` list in routes/index.tsx.
// ---------------------------------------------------------------------------

export type FaqItem = { q: string; a: React.ReactNode; plain: string }

const GLYPHS = '#%&@*+=?!<>/\\{}[]0123456789ABCDEFGHJKLMNPQRSTUVWXYZ'

function useDecode(text: string, active: boolean) {
  const [out, setOut] = useState(active ? '' : text)
  const raf = useRef<number | null>(null)
  useEffect(() => {
    if (!active) return
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduce) { setOut(text); return }
    const start = performance.now()
    const dur = Math.min(900, 280 + text.length * 6)
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / dur)
      const solved = Math.floor(p * text.length)
      let s = text.slice(0, solved)
      for (let i = solved; i < text.length; i++) {
        s += text[i] === ' ' ? ' ' : GLYPHS[Math.floor(Math.random() * GLYPHS.length)]
      }
      setOut(s)
      if (p < 1) raf.current = requestAnimationFrame(tick)
      else setOut(text)
    }
    raf.current = requestAnimationFrame(tick)
    return () => { if (raf.current) cancelAnimationFrame(raf.current) }
  }, [text, active])
  return out
}

function Answer({ item, open, done }: { item: FaqItem; open: boolean; done: boolean }) {
  const decoded = useDecode(item.plain, open && !done)
  return (
    <div className="faq-answer" aria-hidden={!open}>
      <div className="faq-answer-inner">
        <span className="faq-stamp" aria-hidden="true">Cracked!</span>
        {/* While decoding, show the scrambled text; once done, the real answer (with any links). */}
        {open && !done ? <p className="faq-decoding" aria-hidden="true">{decoded}</p> : <div className="faq-text">{item.a}</div>}
      </div>
    </div>
  )
}

export function Faq({ items }: { items: FaqItem[] }) {
  const [open, setOpen] = useState<number | null>(null)
  const [done, setDone] = useState<Record<number, boolean>>({})

  const toggle = (i: number) => {
    setOpen((cur) => (cur === i ? null : i))
    setDone((d) => ({ ...d, [i]: false }))
    const t = Math.min(900, 280 + items[i].plain.length * 6) + 60
    window.setTimeout(() => setDone((d) => ({ ...d, [i]: true })), t)
  }

  return (
    <section className="faq-section" id="faq">
      <div className="faq-heading">
        <p className="eyebrow dark"><span /> Frequently asked</p>
        <h2>Questions?<br /><em>Let’s crack them.</em></h2>
        <p>Tap a padlock to unlock the answer. Still stuck? Call us on <a href="tel:0220537365">022 053 7365</a>.</p>
      </div>
      <ol className="faq-list">
        {items.map((item, i) => {
          const isOpen = open === i
          return (
            <li key={item.q} className={`faq-item${isOpen ? ' open' : ''}`}>
              <button type="button" className="faq-q" aria-expanded={isOpen} aria-controls={`faq-a-${i}`} onClick={() => toggle(i)}>
                <span className="faq-lock" aria-hidden="true">{isOpen ? <LockOpen size={22} /> : <Lock size={22} />}</span>
                <span className="faq-q-text">{item.q}</span>
                <span className="faq-plus" aria-hidden="true" />
              </button>
              <div id={`faq-a-${i}`} className="faq-a-wrap">
                <Answer item={item} open={isOpen} done={!!done[i]} />
              </div>
            </li>
          )
        })}
      </ol>
    </section>
  )
}
