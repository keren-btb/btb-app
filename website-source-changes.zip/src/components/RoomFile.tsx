import { ArrowRight, Clock3, Eye, Lightbulb, MapPin, Puzzle, Ticket, TriangleAlert, Users, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

// ---------------------------------------------------------------------------
// "Case file" room pages. Click a room's photo (or "More about this room") and
// its page opens over the site. The address changes to #room-<id>, so a room can
// be linked to directly and the phone's Back button closes it.
//
// SPOILER PHOTOS: put photos in public/images/spoilers/ and list them in
// `spoilers` below, e.g. { src: '/images/spoilers/sherlock-1.jpg', caption: 'The study' }.
// A spoiler with no src shows a "photo coming soon" frame.
// ---------------------------------------------------------------------------

export type Spoiler = { src?: string; caption: string }

export type RoomInfo = {
  id: string
  name: string
  kicker: string
  image: string
  accent: string
  story: string[]
  facts: { icon: 'time' | 'players' | 'price' | 'level' | 'place'; label: string; value: string }[]
  goodFor: string[]
  tip?: string
  spoilers: Spoiler[]
  book?: { label: string; gameId?: string }
  call?: string
}

const ICONS = { time: Clock3, players: Users, price: Ticket, level: Puzzle, place: MapPin }

function SpoilerTile({ spoiler, asset, index }: { spoiler: Spoiler; asset: (p: string) => string; index: number }) {
  const [open, setOpen] = useState(false)
  return (
    <figure className={`spoiler${open ? ' revealed' : ''}`}>
      <div className="spoiler-photo">
        {spoiler.src ? (
          <img src={asset(spoiler.src)} alt={open ? spoiler.caption : 'Hidden spoiler photo'} loading="lazy" />
        ) : (
          <div className="spoiler-empty">
            <Eye size={26} />
            <span>Spoiler photo {index + 1}<br /><small>coming soon</small></span>
          </div>
        )}
        {!open && (
          <button type="button" className="spoiler-cover" onClick={() => setOpen(true)} aria-label={`Show spoiler photo ${index + 1}`}>
            <span className="spoiler-tape" aria-hidden="true">SPOILER · SPOILER · SPOILER · SPOILER · SPOILER · SPOILER ·</span>
            <span className="spoiler-badge"><TriangleAlert size={22} /> Spoiler alert</span>
            <span className="spoiler-hint">Tap to peek, if you dare</span>
          </button>
        )}
      </div>
      {open && spoiler.src && <figcaption>{spoiler.caption}</figcaption>}
    </figure>
  )
}

export function RoomFile({
  room,
  asset,
  onClose,
  onBook,
}: {
  room: RoomInfo
  asset: (p: string) => string
  onClose: () => void
  onBook: (gameId?: string) => void
}) {
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev }
  }, [onClose])

  return (
    <div className="roomfile-backdrop" onClick={onClose}>
      <article
        className="roomfile"
        role="dialog"
        aria-modal="true"
        aria-labelledby="roomfile-title"
        style={{ '--room-accent': room.accent } as React.CSSProperties}
        onClick={(e) => e.stopPropagation()}
      >
        <button ref={closeRef} type="button" className="roomfile-close" onClick={onClose} aria-label="Close">
          <X size={22} />
        </button>

        <header className="roomfile-hero">
          <img src={room.image} alt={`${room.name}`} />
          <div className="roomfile-hero-text">
            <p className="roomfile-kicker">Case file · {room.kicker}</p>
            <h2 id="roomfile-title">{room.name}</h2>
          </div>
        </header>

        <div className="roomfile-body">
          <div className="roomfile-main">
            <div className="roomfile-story">
              {room.story.map((p) => <p key={p}>{p}</p>)}
            </div>

            {room.tip && (
              <p className="roomfile-tip"><Lightbulb size={18} /> <span>{room.tip}</span></p>
            )}

            <section className="roomfile-spoilers" aria-label="Spoiler photos">
              <h3>Sneak a peek?</h3>
              <p>These photos give a little away. Only look if you don’t mind a few surprises spoiled.</p>
              <div className="spoiler-grid">
                {room.spoilers.map((s, i) => <SpoilerTile key={i} spoiler={s} asset={asset} index={i} />)}
              </div>
            </section>
          </div>

          <aside className="roomfile-side">
            <dl className="roomfile-facts">
              {room.facts.map((f) => {
                const Icon = ICONS[f.icon]
                return (
                  <div key={f.label}>
                    <dt><Icon size={16} /> {f.label}</dt>
                    <dd>{f.value}</dd>
                  </div>
                )
              })}
            </dl>
            <div className="roomfile-goodfor">
              <strong>Great for</strong>
              <ul>{room.goodFor.map((g) => <li key={g}>{g}</li>)}</ul>
            </div>
            {room.book ? (
              <button type="button" className="roomfile-book" onClick={() => onBook(room.book?.gameId)}>
                {room.book.label} <ArrowRight size={18} />
              </button>
            ) : null}
            {room.call && (
              <a className="roomfile-book" href="tel:0220537365">{room.call} <ArrowRight size={18} /></a>
            )}
            <p className="roomfile-small">Questions? Call <a href="tel:0220537365">022 053 7365</a></p>
          </aside>
        </div>
      </article>
    </div>
  )
}
